#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <libgen.h>
//#include "api.h"
//#include "the.h"


int32_t main(int32_t argc, char  *argv[])
{
	printf("----------------  EmbedWay  ----------------\n");
	start_cli();
    return 0;
}
